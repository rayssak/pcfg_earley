package ime.mac5724.earley.testing;

import ime.mac5725.earley.EarleyFinger;
import ime.mac5725.earley.util.ConstantsUtility;
import ime.mac5725.earley.util.TreeBankHandler;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Scanner;

/**
 * @author rayssak
 * @reason Receives a GLC and a portuguese sentence in raw format to 
 * 		   pre-process and generate the formatted Grammar Tree required
 * 		   as the Parser input.
 * 
 * 		   Testing real grammar from Finger's corpus.
 */
public class TestingLC1 {
	
	private static TreeBankHandler treeBank;
	private static EarleyFinger earley;

	private static String time;
	
	private static boolean grammarRecognized;
	private static boolean printRules;
	
	private static LinkedHashSet<String> lexicon;
	private static LinkedHashSet<String> grammarRules;
	private static HashMap<String, ArrayList<String>> grammarTrees;
	
	public static void main(String[] args) {
		
		/* 
		 * - SENTENCE EXAMPLES:
		 * 
		 * 		senhor ofere�o a vossa majestade
		 * 		todas s�o iguais e todas grandes
		 * 		veio at� f�
		 * 		declamei contra a vaidade ,
		 * 		as reflex�es sobre a vaidade dos homens
		 * 		a confiss�o da culpa costuma fazer menor a pena .
		 * 		e que s� em vossa majestade n�o tem : feliz indig�ncia
		 *		ent�o sejam bem aceites
		 *		vem por compaix�o e l�stima
		 *		necessita que primeiro morra o seu autor
		 *		ficam reservadas para serem obras p�stumas
		 *		mais firme ,
		 * 		uma e outra cousa
		 * 		s� assim
		 * 		as achamos
		 * 		j� o n�o �
		 * 		e o tacto s� sente .
		 * 		favorece ao primeiro que encontra ,
		 * 
		 */
		String sentence = args[2];
		printRules = Boolean.valueOf(args[1]);
		
		long timeRan = System.currentTimeMillis();
		
		initializeRequiredObjects();
		readGrammar(args);
		grammarRecognized = earley.recognize(sentence, grammarRules, lexicon);
		
		handleTimeRan(timeRan);
		System.out.println("\n- SENTENCE: " + "\"" + sentence + "\"");
		System.out.println("- TIME: " + time);
		System.out.println("- SENTENCE STATUS: " + (grammarRecognized ? "recognized" : "not recognized"));
		System.out.println("- SENTENCE PRECISION: " + (earley.parse(grammarTrees) ? "precise" : "not precise, " + earley.getPrecision() + " % precision "));
		
		if(grammarRecognized) {
			Scanner input = new Scanner(System.in);
			System.out.println("Do you want to show grammar whole tree (all backpointers)? (y/N)");
			boolean showBackPointers = input.next().equalsIgnoreCase("y") ? true : false;
			if(showBackPointers) {
				ArrayList<String> tree = earley.getBackPointersTree();
				System.out.println("- SYNTATIC TREE (with backpointers):");
				for(int aux=tree.size()-1; aux>=0; aux--)
						System.out.println("\t" + tree.get(aux).replace(ConstantsUtility.FIELD_SEPARATOR, " "));
				
			}
		}
		
	}

	private static void handleTimeRan(long timeRan) {
		timeRan = System.currentTimeMillis() - timeRan;
		long seconds = (timeRan/1000) % 60;
		long minutes = (timeRan/60000) % 60;
		time = minutes + " minutes, " + seconds + " seconds e " + timeRan + " milliseconds";
	}

//	private static void printRules() {
//
//		PrintWriter out = null;
//		try {
//			out = new PrintWriter("C:\\rayssak\\dev\\ime\\all-sentences.txt");
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		for(Entry<String, String> entry : grammarTrees.entrySet()) {
//			out.println(entry.getKey());
//			out.println(entry.getValue());
//		}
//		
////		for(String rule : tmp)
////			out.println(rule);	
////			// Print only head rules
////			if(rule.split(ConstantsUtility.NEXT_ELEMENT_CHAR)[0].equals("ADJ")) {
////				count++;
////				System.out.println(rule);
////			}
////		}
//	}

	private static void initializeRequiredObjects() {
		treeBank = new TreeBankHandler();
		earley = new EarleyFinger();
		grammarRules = new LinkedHashSet<String>();
		lexicon = new LinkedHashSet<String>();
		earley.setPrintRules(printRules);
	}
	
	private static void readGrammar(String[] args) {
		treeBank.readGrammar(new File(args[0]));
		grammarRules = treeBank.getGrammarRules();
		lexicon = treeBank.getLexicon();
		grammarTrees = treeBank.getGrammarTrees();
	}
	
}